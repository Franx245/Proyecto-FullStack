Asunto sugerido: Error en Checkout Pro sandbox con test users: "Hubo un error accediendo a esta pagina" antes de crear el pago

Hola,

estamos integrando Checkout Pro para una tienda propia y necesitamos ayuda con un error reproducible en sandbox.

## Resumen del problema

Al abrir el checkout de una preferencia de prueba, Mercado Pago no llega al flujo normal de login/pago y muestra directamente la pantalla:

`Hubo un error accediendo a esta pagina...`

En otras pruebas del mismo entorno también vimos:

- `ERR_TOO_MANY_REDIRECTS`
- loops en `/challenge/`

Lo importante es que el problema ocurre antes de que exista un pago real: no se crea ningún `payment` y no llega webhook.

## Cuenta y aplicación

- Site: `MLA`
- Seller test user id: `3280065165`
- Seller nickname: `TESTUSER3719552300977747255`
- `users/me` confirma `test_user=true`
- `client_id` que devuelve `users/me.test_data.client_id`: `1719385973552315`
- `client_id` que devuelve la preferencia: `3991009768505159`

## Tienda afectada

- Frontend/backend público usado para reproducir: `https://duelvault-store-api.vercel.app`

## Reproducción 1: preferencia generada por la tienda

- Orden interna: `48`
- Preference id: `3280065165-1c2aced9-d7e2-4e47-8cf1-861d4e99d6c3`
- `sandbox_init_point`:
  `https://sandbox.mercadopago.com.ar/checkout/v1/redirect?pref_id=3280065165-1c2aced9-d7e2-4e47-8cf1-861d4e99d6c3`

Resultado:

- La preferencia se crea correctamente.
- El navegador termina en la pantalla `Hubo un error accediendo a esta pagina...`
- No se crea `payment`.

## Reproducción 2: preferencia creada directo por API

También probamos crear una preferencia directo contra la API de Mercado Pago, fuera de la tienda, para descartar un problema de nuestro backend.

Preference id:

- `3280065165-5549d5c6-91af-4000-9cb9-c65f5fa87542`

Características del payload usado:

- `payer.email`
- `statement_descriptor`
- `expires=true`
- `expiration_date_from`
- `expiration_date_to`
- `notification_url`
- item detallado con `id`, `title`, `description`, `category_id`

Resultado:

- La API acepta la preferencia.
- `init_point` y `sandbox_init_point` son válidos.
- El navegador vuelve a terminar en `Hubo un error accediendo a esta pagina...`
- Tampoco se crea `payment`.

## Buyer test user usado en la reproducción

- Username: `TESTUSER938439403543093719`

No adjuntamos contraseña por seguridad, pero la prueba se ejecutó con credenciales válidas del buyer test correspondiente.

## Evidencia adjunta

- Respuesta de `users/me`
- Preferencia creada por la tienda
- Preferencia creada directo por API
- Búsqueda de pagos por `external_reference` sin resultados
- Snapshot textual de Playwright con la pantalla de error

## Consulta puntual

¿Podrían revisar por qué una preferencia sandbox válida para este seller test user está redirigiendo a una pantalla de error previa al login/pago, incluso cuando la preferencia se crea directamente con la API oficial?

También agradeceríamos confirmación sobre cuál es el `client_id` correcto asociado a esta cuenta de prueba, porque vimos:

- `users/me.test_data.client_id = 1719385973552315`
- `preference.client_id = 3991009768505159`

Gracias.

