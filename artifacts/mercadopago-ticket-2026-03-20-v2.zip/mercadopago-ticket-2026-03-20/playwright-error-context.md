# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - link "Mercado Libre - Donde comprar y vender de todo" [ref=e4] [cursor=pointer]:
      - /url: https://www.mercadolibre.com/
  - main [ref=e5]:
    - generic [ref=e8]:
      - heading "Hubo un error accediendo a esta pagina..." [level=4] [ref=e9]
      - link "Ir a la pÃ¡gina principal" [ref=e11] [cursor=pointer]:
        - /url: https://mercadolibre.com/
```
